#include <iostream>
#include "linkernighan.h"

using namespace std;
using namespace OptimizeName;

int main()
{

  Linkernighan *lk = new Linkernighan(); 

  lk->initialize();

  lk->opt();

  lk->free();

  delete lk;
  
  return 0;
}
