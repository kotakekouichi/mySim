#include <iostream>
#include "node.h"
#include "linkernighan.h"
#include "params.h"
#include "minimum_spanning_tree.h"

using namespace std;

namespace OptimizeName
{

  void Linkernighan::initialize()
  {

    cout << "initialize " << endl;
    const int N = Num;
    double xp, yp;

    nodes = new NodeClass[N];

    int inode = 0;
    //for(int inode = 0; inode < N; ++inode)
    while(inode < N)
    {
      xp = (double) rand() / RAND_MAX; 
      yp = (double) rand() / RAND_MAX;

      if(sq(xp - 0.5) + sq(yp - 0.5) < 0.5 * 0.5  && 0.4 * 0.4 < sq(xp - 0.5) + sq(yp - 0.5))
      {
	nodes[inode].setNo(inode);
	nodes[inode].setPosx(xp);
	nodes[inode].setPosy(yp);
	inode++;
      }
    }

    for(int i = 0; i < N; ++i)
    {
      for(int j = 0; j < N; ++j)
      {
        PathClass tmppath(&nodes[i], &nodes[j]);  
	pathmap[i][j] = tmppath;
      }
    }

  }

  void Linkernighan::free()
  {
    cout << "free" << endl;
    delete [] nodes; 
    bestroute.clear();
  }

  void Linkernighan::opt()
  {
    const int N = Num;
    cout << "opt" << endl;
    generationImplementation();

  }

  void Linkernighan::generationImplementation()
  {
    int iteration = 0; 
    const int N = Num;
    double dist = 0.0;

    MinimumSpanningTree *mst = new MinimumSpanningTree();

    mst->setNodes(nodes);
    mst->initialize();
    mst->opt();
    mst->calc2appRoute();

    vector<PathClass> *route2app = mst->get2appRoute(); 
    
    NodeClass *route = new NodeClass[N];
    for(int i = 0; i < route2app->size(); ++i)
    {
      PathClass *tmpPath = &(route2app->at(i));
      route[i] = nodes[tmpPath->getFromNode()->getNo()];
    }

    //for(int inode = 0; inode < N; ++inode) route[inode] = nodes[inode];

    while( iteration < N )
    {
      dist = distmin;

      NodeClass firstNode = route[0];
      for(int i = 0; i < N - 1; ++i)
      {
	route[i] = route[i + 1];
      }
      route[N - 1] = firstNode;

      double g = 0;
      improvePath(1, route, dist, g);

      if(dist < distmin) 
      {
	setbestroute(route);
	distmin = dist;
	cout << "distmin = " << distmin << endl;
	outputRoute();
	iteration = 0;
      } else
      {
	++iteration;
      }
    }

    outputNode();
    outputRoute();

    //delete [] nodes;

    mst->free();
    delete mst;
    delete [] route;
  }

  int Linkernighan::improvePath(int lambda, NodeClass *route, double &dist, double &g)
  {

    int rval = 0;
    const int N = Num;
    const int alpha = 5;
    const int endnode = N - 1;
    double g2 = 0.0, tmpdist = 0.0;

    NodeClass *oldroute = new NodeClass[N];

    for(int i = 0; i < N; ++i) oldroute[i] = route[i];

    if(lambda >= 10) return 0;

    if(lambda < alpha)
    {

      for(int path = 0; path < N - 1; ++path)
      {

	PathClass wxy(&route[path], &route[path + 1]);
	PathClass wex(&route[endnode], &route[path]);
	g2 = wxy.getval() - wex.getval(); 

	if(g + g2 > 0)
	{

	  for(int ipath = 0; ipath < path + 1; ++ipath)
	    oldroute[ipath] = route[ipath];
	  for(int ipath = path + 1; ipath < N; ++ipath)
	    oldroute[ipath] = route[endnode - ipath + path + 1];

	  tmpdist = 0.0;
	  for(int i = 0, j = 0; i < N; ++i)
	  {
	    j = i != N - 1 ? i + 1 : 0;
	    int fromIdx = oldroute[i].getNo();
	    int toIdx = oldroute[j].getNo();
	    tmpdist += pathmap[fromIdx][toIdx].getval();
	  }

	  if(tmpdist < dist)
	  {
	    for(int i = 0; i < N; ++i) route[i] = oldroute[i];

	    for(int ipath = path + 1; ipath < N; ++ipath)
	      route[ipath] = oldroute[ipath]; 

	    dist = tmpdist;

	    g = g + g2;
	    rval = 1;
	    goto CLEANUP;

	  } else 
	  {
	    rval = improvePath(lambda + 1, oldroute, dist, g); 

	    if(dist < tmpdist) 
	    {
#if 1 
	      for(int i = 0; i < N; ++i) route[i] = oldroute[i];
#endif
	      g = g + g2;
	    }

	    if(rval) goto CLEANUP;
	  }

	} //if g
      }
    } else 
    {

      int idxpath = -1;
      double dbl = -1.0e+10;

      for(int path = 0; path < N - 1; ++path)
      {

	PathClass wxy(&route[path], &route[path + 1]);
	PathClass wex(&route[endnode], &route[path]);
	g2 = wxy.getval() - wex.getval(); 

	if(g2 > dbl)
	{
	  dbl = g2;
	  idxpath = path;
	}
      }

      if(dbl > 0)
      {
	//cout << lambda << " " << idxpath <<  " " <<  dbl + g << endl;

	for(int ipath = 0; ipath < idxpath + 1; ++ipath)
	  oldroute[ipath] = route[ipath];
	for(int ipath = idxpath + 1; ipath < N; ++ipath)
	  oldroute[ipath] = route[endnode - ipath + idxpath + 1];

	tmpdist = 0;
	for(int i = 0, j = 0; i < N; ++i)
	{
	  j = i != N - 1 ? i + 1 : 0;
	  int fromIdx = oldroute[i].getNo();
	  int toIdx = oldroute[j].getNo();
	  tmpdist += pathmap[fromIdx][toIdx].getval();
	}

	if(tmpdist < dist)
	{
	  for(int i = 0; i < idxpath + 1; ++i) route[i] = oldroute[i];
	  for(int ipath = idxpath + 1; ipath < N; ++ipath)
	    route[ipath] = oldroute[ipath]; 

	  dist = tmpdist;
	  rval = 1;

	  g = g  + dbl;
	  goto CLEANUP;
	} else 
	{
	  rval = improvePath(lambda + 1, oldroute, dist, g); 

#if 1
	  if(dist < tmpdist) 
	  {
	    for(int i = 0; i < N; ++i) route[i] = oldroute[i];
	  }
	  g = g + dbl;
#endif

	  if(rval) goto CLEANUP;
	}
      }
    }

CLEANUP:

    delete [] oldroute;

    return rval;
  }

  void Linkernighan::outputNode()
  {
    const int N = Num;
    NodeClass* Nodes = getnodes();
    ofstream nodefile("nodes.dat");

    for(int i = 0; i < N; ++i)
      nodefile << Nodes[i].getPosx() << "\t" << Nodes[i].getPosy() << endl;

    nodefile.close();
    return;
  }

  void Linkernighan::outputRoute()
  {
    const int N = Num; 
    ofstream ofile("route.gnu");

    ofile << "#!/bin/gnuplot" << endl;
    ofile << "set size square" << endl;
    ofile << "set xrange [0.0:1.0]" << endl;
    ofile << "set yrange [0.0:1.0]" << endl;
    ofile << "plot '-' w l,  'nodes.dat'" << endl;

    for(int i = 0; i < bestroute.size(); ++i)
    {
      PathClass *tmpPath = &(bestroute[i]);

      ofile << tmpPath->getFromNode()->getPosx() << " " << tmpPath->getFromNode()->getPosy() << endl;
      ofile << tmpPath->getToNode()->getPosx() << " " << tmpPath->getToNode()->getPosy() << endl;

      ofile << endl;
    }

    ofile.close();

  }

  void Linkernighan::setbestroute(NodeClass *route)
  {
    //cout << "set best route"<< endl;
    const int N = Num;

    bestroute.clear();
    double dist = 0.0;
    for(int i = 0; i < N; ++i)
    {
      int fromIdx = i;
      int toIdx = i != N - 1 ? i + 1 : 0;
      PathClass tmppath(&route[fromIdx], &route[toIdx]); 

      dist += tmppath.getval();
      bestroute.push_back(tmppath);
    }
    cout << "testdist = " << dist << endl;
    return;
  }
};
