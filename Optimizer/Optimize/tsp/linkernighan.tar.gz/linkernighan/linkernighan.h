#ifndef _LINKERNIGHAN_H_
#define _LINKERNIGHAN_H_
#include "opt.h"
#include "node.h" 
#include "utils.h"
#include "params.h"

namespace OptimizeName
{
  class Linkernighan : public OptClass
  {
    public:
      double distmin;
      NodeClass *nodes; 
      vector<PathClass> bestroute;
      map<int, map<int, PathClass> > pathmap;

      Linkernighan(){distmin = 1.0e+10;}
      
      void initialize();
      void opt();
      void generationImplementation();
      int improvePath(int lambda, NodeClass *nodes, double &dist, double &g);
      void outputNode();
      void outputRoute();
      void setbestroute(NodeClass *route);
      void free(); 

      NodeClass* getnodes(){return nodes;}
      double getdistmin(){return distmin;}
  };

};
#endif 
