#ifndef _OPT_H_
#define _OPT_H_
#include "params.h"
#include "utils.h"

using namespace std;

namespace OptimizeName
{
  class OptClass
  {
  };
}

#endif 
