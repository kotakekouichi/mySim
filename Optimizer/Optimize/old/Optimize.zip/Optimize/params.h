#ifndef _PARAMS_H_
#define _PARAMS_H_

#define Nx (Num * (Num - 1) / 2) // for branch and cut
#define Num 200// Number of Node

#endif
