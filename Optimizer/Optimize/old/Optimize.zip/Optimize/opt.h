#ifndef _OPT_H_
#define _OPT_H_
#include "params.h"
#include "function.h"
#include <vector>

using namespace std;

namespace OptimizeName
{

  class OptClass;
  class Function;
  const double eps = 1.0e-12;

  class Function : public AbstFunction
  {
    private:

    public:
      Function()
      {
	this->Coeff = new coeff[Nx];
	this->firstCoeff = NULL;

	for(int i = 0; i < Nx; ++i)
	{
	  this->Coeff[i].ix = i;
	  this->Coeff[i].index = i;
	  this->Coeff[i].val = 0.0;
	  this->Coeff[i].preCoeff = NULL;
	  this->Coeff[i].nextCoeff = NULL;
	}

	this->Coeff[Nx].ix = -1;
	this->Coeff[Nx].index = -1;
	this->Coeff[Nx].val = 0.0;
	this->Coeff[Nx].preCoeff = NULL;
	this->Coeff[Nx].nextCoeff = NULL;
      }

      void SwapVariable(int xpivod, int ix,Function &Bi);
      int getXpivodCol(vector<Function> &B);
      int getXpivodRow(int &xpivod, vector<Function> &B);
      void migration(int xpivodcol);

  };
#if 0
  class OptClass
  {
    protected:
      Function *fobj;
      vector<Function> g; 
    public:

      OptClass(){this->fobj = new Function();g.reserve(10000000);}

      Function *getObjectiveFunction(){return fobj;}
      vector<Function> *getConstraintFunction(){return &g;} 
      
      virtual void initialize();
      virtual void opt();
      virtual void clear();

      virtual ~OptClass(){}
  };
#endif
};

#endif 
