#include <iostream>
#include <fstream>
#include <vector>
#include "simplex.h"
#include "params.h"
#include "function.h"
#include <math.h>

using namespace std;

double sq(double val){return val*val;}

namespace OptimizeName 
{
  /* --- Function --- */
  void Simplex::run()
  {
  }

  void Simplex::initialize()
  {
    int idx = 0, *indexes = new int[Num*Num];
    double *xp = new double[Num], *yp = new double[Num], *val = new double[Nx];
    
    Function *pfobj = getObjectiveFunction();
    vector<Function> *gfunc = getConstraintFunction();
    pfobj->setobject(minimization);

    for(int i = 0; i < Num; ++i)
    {
      xp[i] = (double) rand() / (double) RAND_MAX;
      yp[i] = (double) rand() / (double) RAND_MAX;
    }

    // x_idx = x_ij
    for(int i = 0; i < Num; ++i)
    {
      for(int j = i + 1; j < Num; ++j)
      {
	val[idx] = (sq(xp[i] - xp[j]) + sq(yp[i] - yp[j]));
	indexes[i + j*Num] = idx;	
	++idx;
      }
    }

    for(int i = 0; i < Nx; ++i)
    {
      pfobj->Coeff[i].val = val[i];
    }

    //次数LP緩和
    for(int i = 0; i < Num; ++i)
    {
      Function tmp1, tmp2;
      tmp1.ix = gfunc->size() + Nx;
      tmp2.ix = gfunc->size() + Nx + 1;
      tmp1.constTermVal = -2;
      tmp2.constTermVal  = 2;
      
      for(int k = 0; k < Num; ++k)
      {
	if(k < i)
	{
	  idx = indexes[k + i*Num]; 
	}
        else if(k > i)
	{ 
	  idx = indexes[i + k*Num];
	}
	else 
	  continue;
	tmp1.Coeff[idx].val = 1;
	tmp2.Coeff[idx].val = -1;
      }
      gfunc->push_back(tmp1);
      gfunc->push_back(tmp2);
    } 

    for(int i = 0; i < Nx; ++i)
    {
      Function tmp;
      tmp.ix = gfunc->size() + Nx;
      tmp.constTermVal = 1;
      tmp.Coeff[i].val = -1;
      gfunc->push_back(tmp);
    }
    
    pfobj->conectChain();
    for(int i = 0; i < gfunc->size(); ++i)
    {
      gfunc->at(i).conectChain();
    }

    delete [] xp;
    delete [] yp;
    delete [] val;
    delete [] indexes;

    return;

  }

  void Simplex::free()
  {
    Function *pfobj = getObjectiveFunction();
    vector<Function> *B = getConstraintFunction();
    const int Nconstraint = B->size(); 

    delete [] pfobj->Coeff;
    delete pfobj;
    for(int i = 0; i < Nconstraint; ++i)
      delete [] B->at(i).Coeff;
    B->clear();
  }

  void Simplex::opt()
  {
    Function *pfobj = this->getObjectiveFunction();
    vector<Function> *pB = this->getConstraintFunction();
    const int Nconstraint = pB->size();
    int xpivod = 0;
    int xpivodrow = 0;
    double time1 = 0.0; 
    clock_t t1 = clock();
    //double dxpivodrow = 1.0e6, dddx, aaa;
    double dddx = 0.0, aaa;
    
    this->getFeasibleInitilize();
    
    while(1)
    {
      xpivod = pfobj->getXpivodCol(*pB);
      //if(xpivod < 0) break;
      if(xpivod < 0) xpivod = 0;
      xpivodrow = 0;

      t1 = clock();
      for(int ic = 0; ic < Nconstraint; ++ic)
      {
	aaa = pB->at(ic).Coeff[xpivod].val;
	if(aaa >= 0)
	{
	  continue;
	}
	dddx = -pB->at(ic).constTermVal / aaa;
      }
      t1 = clock() - t1;
      time1 = (double) t1 / CLOCKS_PER_SEC;
      cout << time1 << endl;
      getchar();
    }

  }

  void Function::SwapVariable(int xpivod, int ix, Function &Bi)
  {
    double a = this->Coeff[xpivod].val; // apivod
    if(a == 0.0){return ;}

    this->Coeff[xpivod].ix = ix; //新しい基底変数に置き換える

    for(coeff *aCoeff = Bi.firstCoeff; aCoeff != NULL; aCoeff = aCoeff->nextCoeff)
    //for(int i = 0; i < Nx + 1; ++i)
    {
      //coeff *aCoeff = &(Bi.Coeff[i]);
      if(aCoeff->val == 0.0) continue;
      int index = aCoeff->index; // index of array 
      if(this->Coeff[index].val == 0.0)
      {
	coeff *CoeffNew = &this->Coeff[index];
	if(fabs(a * aCoeff->val) < eps){CoeffNew->val = 0.0;continue;}
	
	CoeffNew->index = aCoeff->index;
	CoeffNew->ix = aCoeff->ix;
	CoeffNew->val = a * aCoeff->val;
	CoeffNew->nextCoeff = this->firstCoeff;
	this->firstCoeff->preCoeff = CoeffNew;
	this->firstCoeff = CoeffNew;
	this->firstCoeff->preCoeff = NULL;
      }
      else 
      {
	this->Coeff[index].val = a * aCoeff->val 
	  + (index != xpivod ? this->Coeff[index].val : 0);  

	if(fabs(this->Coeff[index].val) < eps) this->Coeff[index].val = 0.0;

	if(this->Coeff[index].val == 0.0)
	{
	  if(this->firstCoeff != &this->Coeff[index])
	  {
	    this->Coeff[index].preCoeff->nextCoeff = this->Coeff[index].nextCoeff;
	    if(this->Coeff[index].nextCoeff != NULL) 
	      this->Coeff[index].nextCoeff->preCoeff = this->Coeff[index].preCoeff;
	  }
	  else 
	  {
	    this->firstCoeff = this->Coeff[index].nextCoeff;
	    this->firstCoeff->preCoeff = NULL;
	  }
	}

	  
      }
    }

    this->constTermVal = a * Bi.constTermVal + this->constTermVal;
    if(fabs(this->constTermVal) < eps) this->constTermVal = 0.0;

    return ;
  }

  int Function::getXpivodCol(vector<Function> &pB)
  {
    int xpivod = -1;
    double maxval = 0.0;
    //hoge //koko?
    
    //for(int i = 0; i < Nx + 1; ++i)
    for(coeff *aCoeff = this->firstCoeff; aCoeff != NULL; aCoeff = aCoeff->nextCoeff)
    {
      //coeff *aCoeff = &(this->Coeff[i]);
      if(aCoeff->val == 0.0) continue;
      if((this->getobject() == maximization && aCoeff->val > 0 && aCoeff->index >= 0) ||
	  (this->getobject() == minimization  && aCoeff->val < 0 && aCoeff->index >= 0))
      {
	if((maxval < aCoeff->val && this->getobject() == maximization) || 
	   (maxval > aCoeff->val && this->getobject() == minimization) ) 
	{
	  for(int ic = 0; ic < pB.size(); ++ic)
	  {
	    if(pB.at(ic).Coeff[aCoeff->index].val < 0 && fabs(pB.at(ic).Coeff[aCoeff->index].val) > eps)
	    {
	      maxval = aCoeff->val;
	      xpivod = aCoeff->index;
	      break;
	    }
	  }
	}
      }
    }

    return xpivod;
  }

  int Function::getXpivodRow(int &xpivod, vector<Function> &B)
  {
    int xpivodrow = 1000000;
    double dxpivodrow = 1.0e6;
    double b  = 0.0, dx = 0.0;
    const int Nconstraint = B.size();
    bool artificialFlag = false;

    for(int i = 0; i < Nconstraint; ++i)
    {
      b = B[i].constTermVal;
      if(b < 0.0) artificialFlag = true;
      if(artificialFlag) break;
    }

    dxpivodrow = artificialFlag ? -10000000 : 10000000;

    for(int i = 0; i < Nconstraint; ++i)
    {
      Function *gfunc = &B[i];
      double a = gfunc->Coeff[xpivod].val;
      if(a < 0 && fabs(a) > eps)
      {
	dx = -gfunc->constTermVal / a;
      }
      else 
      {
	dx = 1.0e+30;
      }

      if(!artificialFlag) 
      {
	if(dx >= 0 && dxpivodrow > dx)
	{
	  xpivodrow = i;
	  dxpivodrow = dx; 
	}
      }
      else 
      {
	if(dx >= 0 && dxpivodrow < dx)
	{
	  xpivodrow = i;
	  dxpivodrow = dx;
	}
      }
    }

    return xpivodrow;
  }

  void Function::migration(int xpivodcol)
  {
    int ix = this->ix;
    double a = -this->Coeff[xpivodcol].val;
    
    this->ix = this->Coeff[xpivodcol].ix;
    this->Coeff[xpivodcol].val = -1.0;
    this->Coeff[xpivodcol].ix = ix;
    
    int counter = 0;
    for(coeff *aCoeff = this->firstCoeff; aCoeff != NULL; aCoeff = aCoeff->nextCoeff)
    //for(int i = 0; i < Nx + 1; ++i)
    {
    //  coeff *aCoeff = &(this->Coeff[i]);
      aCoeff->val /= a;
      if(counter >= Nx + 1) cout << "aaaaaaa" << endl;
      ++counter;
    }

    this->constTermVal /= a;

  }

  void Simplex::getFeasibleInitilize()
  {
    cout << "getF" << endl;
    Function *fobj = new Function(); 
    Function *pfobj = getObjectiveFunction();
    setArtificialVariable(fobj);

    vector<Function> *pB = this->getConstraintFunction();
    int artitermIdx = Nx; // 人工変数が格納されている配列インデックス
    const int Nconstraint = pB->size();
    int xpivod = artitermIdx; 
    int xpivodrow = fobj->getXpivodRow(xpivod, *pB);
    int ix = pB->at(xpivodrow).ix;
    
    artitermIdx = xpivod;

    pB->at(xpivodrow).migration(xpivod);

    fobj->SwapVariable(xpivod, ix, pB->at(xpivodrow));
    pfobj->SwapVariable(xpivod, ix, pB->at(xpivodrow));
    for(int ic = 0; ic < Nconstraint; ++ic)
    {
      if(ic == xpivodrow) continue;
      pB->at(ic).SwapVariable(xpivod, ix ,pB->at(xpivodrow));
    }
    
    cout << "start " << endl;
    while(xpivod >= 0)
    {
      xpivod = fobj->getXpivodCol(*pB);
    
      if(xpivod == -1) break;

      xpivodrow = fobj->getXpivodRow(xpivod, *pB);
      ix = pB->at(xpivodrow).ix;
   
      pB->at(xpivodrow).migration(xpivod);
      if(pB->at(xpivodrow).Coeff[xpivod].val == 0.0){continue;}

      if(ix == Nx + Nconstraint) artitermIdx = xpivod; 
      // y = const + a1*x1 + ... + apivod * xpivod + .. 
      // Bxpivodrow = x_ix = bxpivodrow - a1,xpivodrow * x1 - ...   
      fobj->SwapVariable(xpivod, ix, pB->at(xpivodrow));
      pfobj->SwapVariable(xpivod, ix, pB->at(xpivodrow));
      for(int ic = 0; ic < Nconstraint; ++ic)
      {
	if(ic == xpivodrow) continue;
	pB->at(ic).SwapVariable(xpivod, ix ,pB->at(xpivodrow));
      }
    }
    
    checkBasicParams(fobj, artitermIdx);

#if 1
    if(pfobj->Coeff[artitermIdx].preCoeff == NULL)
    {  
      pfobj->firstCoeff = pfobj->Coeff[artitermIdx].nextCoeff;
      pfobj->firstCoeff->preCoeff = NULL;
    }
    else 
    {
      pfobj->Coeff[artitermIdx].preCoeff->nextCoeff = pfobj->Coeff[artitermIdx].nextCoeff;
      if(pfobj->Coeff[artitermIdx].nextCoeff != NULL)
	pfobj->Coeff[artitermIdx].nextCoeff->preCoeff = pfobj->Coeff[artitermIdx].preCoeff;
    }

    for(int ic = 0; ic < Nconstraint; ++ic)
    {
      if(pB->at(ic).Coeff[artitermIdx].val == 0.0) continue;
      pB->at(ic).Coeff[artitermIdx].val = 0.0;
      if(pB->at(ic).Coeff[artitermIdx].preCoeff == NULL)
      {
	pB->at(ic).firstCoeff = pB->at(ic).Coeff[artitermIdx].nextCoeff;
	pB->at(ic).firstCoeff->preCoeff = NULL;
      }
      else 
      {
	pB->at(ic).Coeff[artitermIdx].preCoeff->nextCoeff = pB->at(ic).Coeff[artitermIdx].nextCoeff;
	if(pB->at(ic).Coeff[artitermIdx].nextCoeff != NULL )  
	  pB->at(ic).Coeff[artitermIdx].nextCoeff->preCoeff = pB->at(ic).Coeff[artitermIdx].preCoeff;
      }
    }
#endif

    delete [] fobj->Coeff;
    delete fobj;
    cout << "get Feasible Initialize " << endl;
  }

  void Simplex::setArtificialVariable(Function *pfobj)
  {
    vector<Function> *pB = this->getConstraintFunction();
    const int artitermIdx = Nx ;
    const int Nconstraint = pB->size();

    pfobj->Coeff[Nx].val = -1;
    pfobj->conectChain();
    pfobj->Coeff[artitermIdx].ix = Nx + pB->size();
    pfobj->Coeff[artitermIdx].index = Nx; 
    pfobj->setobject(maximization);

    for(int i = 0; i < Nconstraint; ++i)
    {
      Function *constFunc = &pB->at(i);
      constFunc->Coeff[Nx].ix = Nx + pB->size();
      constFunc->Coeff[artitermIdx].index = Nx;
      if(constFunc->constTermVal >= 0.0) continue;
      constFunc->Coeff[artitermIdx].val = 1.0; 
      
      coeff *tmpC = &(constFunc->Coeff[artitermIdx]);
      tmpC->nextCoeff = constFunc->firstCoeff;

      if(constFunc->firstCoeff != NULL)
      {
	constFunc->firstCoeff->preCoeff = tmpC;
      }
      constFunc->firstCoeff = tmpC;
     
    }
  }

  //人工変数が非基底変数か
  //もしそうならば、基底変数へ
  void Simplex::checkBasicParams(Function *fobj, int &artitermIdx)
  {
    Function *pfobj = this->getObjectiveFunction();
    vector<Function> *gfunc = this->getConstraintFunction();
    const int artitermIx = Nx + gfunc->size(); 
    const int Nconstraint = gfunc->size();
    bool violationFlag = false; 
    int xpivodrow = -1;

    for(int i = 0; i < gfunc->size(); ++i)
    {
      if(artitermIx == gfunc->at(i).ix)
      {
	violationFlag = true;	
	xpivodrow = i;
	break;
      }
    }
   
    if(!violationFlag) return; 

    int xpivod = gfunc->at(xpivodrow).firstCoeff->index;
    int ix = gfunc->at(xpivodrow).ix;

    gfunc->at(xpivodrow).migration(xpivod);

    fobj->SwapVariable(xpivod, ix, gfunc->at(xpivodrow));
    pfobj->SwapVariable(xpivod, ix, gfunc->at(xpivodrow));
    for(int ic = 0; ic < Nconstraint; ++ic)
    {
      if(ic == xpivodrow) continue;
      gfunc->at(ic).SwapVariable(xpivod, ix ,gfunc->at(xpivodrow));
    }

    artitermIdx = xpivod;
  }
};
