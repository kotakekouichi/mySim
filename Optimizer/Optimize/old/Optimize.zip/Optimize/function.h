#ifndef _FUNC_H
#define _FUNC_H
#include <iostream>
#include "params.h"

//目的関数を最大化、最小化するか
enum eObject
{
  maximization,
  minimization,
};

//関数の係数クラス
class coeff 
{
  public:
    unsigned int index;
    unsigned int ix;
    coeff *nextCoeff; 
    coeff *preCoeff;
    double val;
    coeff()
    {
      this->val = 0.0;
      this->preCoeff = NULL;
      this->nextCoeff = NULL;
    }
};

//関数クラス
class AbstFunction
{
  private:
      eObject objecttype;
  public :

    unsigned int ix;
    coeff *firstCoeff;
    coeff *Coeff;
    double constTermVal;

    AbstFunction()
    {
    }

    inline void setobject(eObject value){this->objecttype = value;}
    inline eObject getobject(){return this->objecttype;}

    void conectChain()
    {
      this->firstCoeff = NULL;
      coeff *Coeff = this->firstCoeff;

      for(unsigned int i = 0; i < Nx + 1; ++i)
      {
	if(this->Coeff[i].val == 0) continue;

	Coeff = &this->Coeff[i];
	Coeff->nextCoeff = this->firstCoeff;
	if(this->firstCoeff != NULL)
	  this->firstCoeff->preCoeff = Coeff;
	this->firstCoeff = Coeff;
      }
    }
    
};
#endif
